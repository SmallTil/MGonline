from flask import Flask, render_template, request, send_file
import os
import subprocess
from threading import Thread

app = Flask(__name__)

class DownloadThread(Thread):
    def __init__(self, url, directory, filename, audio_only):
        super().__init__()
        self.url = url
        self.directory = directory
        self.filename = filename
        self.audio_only = audio_only
        self.result = None
        self.error = None

    def run(self):
        if not self.url.startswith('http'):
            self.url = f"ytsearch:{self.url}"

        if self.audio_only:
            command = [
                'yt-dlp',
                '-o', f"{self.directory}/{self.filename}.%(ext)s",
                '-x',
                '--audio-format', 'mp3',
                '--audio-quality', '0',
                '--postprocessor-args', '-acodec libmp3lame',
                self.url
            ]
        else:
            command = [
                'yt-dlp',
                '-o', f"{self.directory}/{self.filename}.%(ext)s",
                '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4',
                self.url
            ]

        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()

        if process.returncode == 0:
            self.result = "Download completed"
        else:
            self.error = stderr.decode('utf-8').strip()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download():
    url = request.form['url']
    filename = request.form['filename'] or "video"
    audio_only = 'audio_only' in request.form

    download_dir = os.path.join(os.getcwd(), 'downloads')
    os.makedirs(download_dir, exist_ok=True)

    thread = DownloadThread(url, download_dir, filename, audio_only)
    thread.start()
    thread.join()

    if thread.error:
        return f"Error: {thread.error}", 400
    else:
        # Find the downloaded file
        for file in os.listdir(download_dir):
            if file.startswith(filename):
                file_path = os.path.join(download_dir, file)
                return send_file(file_path, as_attachment=True)

        return "File not found", 404

if __name__ == '__main__':
    app.run(debug=True)
